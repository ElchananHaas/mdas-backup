gps-msgs
========

ROS messages for common low-level data output by GPS receivers
