# babs_nav

Your description goes here

## Example usage

## Running tests/demos
    
Run JDI then roslaunch babs_nav init_hw.launch then roslaunch sentry_urdf start_rviz.launch for physical robot operation.

Run roslaunch babs_nav init_sim.launch (with NWA Planner installed) for a sample simulation operation.
