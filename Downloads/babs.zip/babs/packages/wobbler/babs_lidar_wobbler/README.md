# Package: babs_lidar_wobbler

This package works with dynamixel_motor_driver and hokuyo_node packages (as well a hardware for a Hokuyo 2D LIDAR and a Dynamixel mx-28 motor) to provide point cloud data sets on a continual basis based on the wobbling LIDAR for the BABS mobile sentry system.

# Package dependencies
Needs many things.
But the launch file (start_wobbler.launch) explicitly calls 

# Usage
Start everything you need by running the only launch file: start_wobbler.launch. This starts static and dynamic transforms, motor wobbling publishers, and the point cloud stitcher nodes.

# Node descriptions

YO FILL ME OUT DOG

