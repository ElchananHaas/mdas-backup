TODO LIST
=========

- use remapping in the topic output settings instead passing a string for the desired topic  

- add L1Range msg capability,
	- determine which to use by testing l2 capable boolean