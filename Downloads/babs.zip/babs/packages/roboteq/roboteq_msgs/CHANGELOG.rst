^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package roboteq_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2015-10-16)
------------------
* Add mode for stop, clear control constants; this is an MD5 breakage for Indigo.
* Contributors: Mike Purvis

0.1.2 (2015-01-09)
------------------

0.1.1 (2013-11-30)
------------------

0.1.0 (2013-11-28)
------------------
* Use rad/s for motor velocity, rather than roboteq-standard RPM.
* Catkinize roboteq_msgs
