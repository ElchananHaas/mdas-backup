^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package roboteq_driver
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2015-10-16)
------------------
* Explicit stop commands at 10Hz when uncommanded.
* Add option to command position control, specifying separate sets of constants in MBS.
* Fixed channel.cpp line 85 to properly pass variable relevent to channel
* Contributors: Mike Purvis, Thomas Watters

0.1.2 (2015-01-09)
------------------

0.1.1 (2013-11-30)
------------------

0.1.0 (2013-11-28)
------------------
* Initial cut of catkinized MBS-based driver for Hydro.
