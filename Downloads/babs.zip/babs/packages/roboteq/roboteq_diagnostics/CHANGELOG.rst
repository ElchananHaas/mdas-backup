^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package roboteq_diagnostics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2015-10-16)
------------------

0.1.2 (2015-01-09)
------------------
* Add queue_size, fixes `#4 <https://github.com/g/roboteq//issues/4>`_
* Contributors: Mike Purvis

0.1.1 (2013-11-30)
------------------
* Fix name of python node to install.

0.1.0 (2013-11-28)
------------------
* Basic catkin conversion, some include file rearrangement and cleanup.
